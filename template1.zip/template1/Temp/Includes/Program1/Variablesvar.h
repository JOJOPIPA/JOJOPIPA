/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1648892660_6_
#define _BUR_1648892660_6_

#include <bur/plctypes.h>

/* Constants */
#ifdef _REPLACE_CONST
#else
#endif


/* Variables */
_BUR_LOCAL plcbit button4;
_BUR_LOCAL plcbit button3;
_BUR_LOCAL plcbit button2;
_BUR_LOCAL plcbit button1;
_BUR_LOCAL plcbit led[4];





__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/Program1/Variables.var\\\" scope \\\"local\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1648892660_6_ */

