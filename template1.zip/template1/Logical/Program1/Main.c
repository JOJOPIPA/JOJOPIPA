
#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
  #include <AsDefault.h>
#endif

void _INIT ProgramInit(void)
{
	button1 = 0;
	button2 = 0;
	button3 = 0;
	button4 = 0;
	led[0] = 0;
	led[1] = 0;
	led[2] = 0;
	led[3] = 0;
}

void _CYCLIC ProgramCyclic(void)
{
	if (button1 == 1)
	{
		led[0] = !led[0];
		led[2] = !led[2];
		button1 =!button1;
	}
	if (button2 == 1)
	{
		led[1] = !led[1];
		led[3] = !led[3];
		button2 =!button2;
	}
	if (button3 == 1)
	{
		led[0] = !led[0];
		led[1] = !led[1];
		button3 =!button3;
	}
	if (button4 == 1)
	{
		led[2] = !led[2];
		led[3] = !led[3];
		button4 =!button4;
	}
	
}

void _EXIT ProgramExit(void)
{

}

